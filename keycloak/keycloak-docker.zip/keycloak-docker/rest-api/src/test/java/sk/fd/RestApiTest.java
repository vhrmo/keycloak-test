package sk.fd;

import org.junit.jupiter.api.*;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.GroupRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Everything is created in realm "Test"
 * - create roles: gzs_test, gzs_admin, gzs_super_admin
 * - create groups: gzsTestGrp, gzsAdminGrp, gzsSuperAdminGrp
 * - assign roles to groups
 * - create users
 * - assign users to groups
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RestApiTest {

    private RealmResource realm;

    @BeforeEach
    void beforeEach() {

        Keycloak keycloak = Keycloak.getInstance(
                "http://localhost:8080/auth",
                "master",
                "admin",
                "admin",
                "admin-cli");

        realm = keycloak.realm("Test");
    }

    @Test
    @Order(1)
    void testCreateRoles() {
        Set<String> existingRoles = realm.roles().list().stream().map(RoleRepresentation::getName).collect(Collectors.toSet());
        Set<String> desiredRoles = Set.of("gzs_test", "gzs_admin", "gzs_super_admin");

        desiredRoles.stream()
                .filter(roleName -> !existingRoles.contains(roleName))
                .forEach(roleName -> {
                    RoleRepresentation roleRepresentation = new RoleRepresentation();
                    roleRepresentation.setName(roleName);
                    realm.roles().create(roleRepresentation);
                });

        Set<String> rolesAfterTest = realm.roles().list().stream().map(RoleRepresentation::getName).collect(Collectors.toSet());
        desiredRoles.forEach(roleName -> assertTrue(rolesAfterTest.contains(roleName)));
    }


    @Test
    @Order(2)
    void testCreateGroups() {
        Set<String> existingGroups = realm.groups().groups().stream().map(GroupRepresentation::getName).collect(Collectors.toSet());
        Set<String> desiredGroups = Set.of("gzsTestGrp", "gzsAdminGrp", "gzsSuperAdminGrp");

        desiredGroups.stream()
                .filter(groupName -> !existingGroups.contains(groupName))
                .forEach(groupName -> {
                    GroupRepresentation groupRepresentation = new GroupRepresentation();
                    groupRepresentation.setName(groupName);
                    realm.groups().add(groupRepresentation);
                });

        Set<String> groupsAfterTest = realm.groups().groups().stream().map(GroupRepresentation::getName).collect(Collectors.toSet());
        desiredGroups.forEach(groupName -> assertTrue(groupsAfterTest.contains(groupName)));
    }

    @Test
    @Order(3)
    void testAssignRolesToGroups() {
        Map</*group name*/ String, GroupRepresentation> existingGroups = realm.groups().groups().stream().collect(Collectors.toMap(GroupRepresentation::getName, Function.identity()));
        Map<String, String> groupRoleMap = Map.of("gzsTestGrp", "gzs_test", "gzsAdminGrp", "gzs_admin", "gzsSuperAdminGrp", "gzs_super_admin");

        groupRoleMap.forEach((key, value) -> {
            RoleRepresentation roleRepresentation = realm.roles().get(value).toRepresentation();
            String groupId = existingGroups.get(key).getId();

            realm.groups().group(groupId).roles().realmLevel().add(List.of(roleRepresentation));
        });
    }

    @Test
    @Order(4)
    void testCreateUsers() {

        List.of(
                createUserRepresentation("havelok", "Havelok", "Vetinary", "havelok.vetinary@shades.com", "havelok"),
                createUserRepresentation("sam", "Sam", "Vimes", "sam.vimes@ankh.com", "sam"),
                createUserRepresentation("fred", "Frederic", "Colon", "frederic.colon@morpork.com", "fred"),
                createUserRepresentation("noby", "Noby", "Nobs", "noby.nobs@morpork.com", "noby"),
                createUserRepresentation("carrot", "Carrot", "Ironfounderson", "carrot.ironfounderson@shades.com", "carrot")
        ).stream()
                .filter(user -> realm.users().search(user.getUsername()).size() == 0)
                .forEach(user -> realm.users().create(user));

    }

    @Test
    @Order(5)
    void testAddUsersToGroups() {
        Map.of(
                "havelok", "/gzsSuperAdminGrp",
                "sam", "/gzsSuperAdminGrp",
                "fred", "/gzsAdminGrp",
                "noby", "/gzsTestGrp",
                "carrot", "/gzsTestGrp").forEach((key, value) -> {

            UserRepresentation userRepresentation = realm.users().search(key).get(0);
            UserResource userResource = realm.users().get(userRepresentation.getId());
            GroupRepresentation groupRepresentation = realm.getGroupByPath(value);
            userResource.joinGroup(groupRepresentation.getId());
        });
    }


    @Disabled
    @Test
    void testDisableUser() {
        UserRepresentation userRepresentation = realm.users().search("sam").get(0);
        UserResource userResource = realm.users().get(userRepresentation.getId());

        userRepresentation.setEnabled(false);
        userResource.update(userRepresentation);
    }


    @Disabled
    @Test
    void testDeleteUser() {
        UserRepresentation userRepresentation = realm.users().search("sam").get(0);
        realm.users().delete(userRepresentation.getId());
    }


    @Disabled
    @Test
    void testResetPassword() {
        UserRepresentation userRepresentation = realm.users().search("sam").get(0);
        UserResource userResource = realm.users().get(userRepresentation.getId());

        CredentialRepresentation credentialRepresentation = new CredentialRepresentation();
        credentialRepresentation.setType(CredentialRepresentation.PASSWORD);
        credentialRepresentation.setValue("reset");

        userResource.resetPassword(credentialRepresentation);
    }

    private UserRepresentation createUserRepresentation(String username, String firstName, String lastName, String email, String password) {
        UserRepresentation userRepresentation = new UserRepresentation();
        userRepresentation.setUsername(username);
        userRepresentation.setFirstName(firstName);
        userRepresentation.setLastName(lastName);
        userRepresentation.setEmail(email);
        userRepresentation.setEnabled(true);

        CredentialRepresentation credentialRepresentation = new CredentialRepresentation();
        credentialRepresentation.setType(CredentialRepresentation.PASSWORD);
        credentialRepresentation.setValue(password);

        List<CredentialRepresentation> credentials = new ArrayList<>();
        credentials.add(credentialRepresentation);
        userRepresentation.setCredentials(credentials);

        return userRepresentation;
    }
}
