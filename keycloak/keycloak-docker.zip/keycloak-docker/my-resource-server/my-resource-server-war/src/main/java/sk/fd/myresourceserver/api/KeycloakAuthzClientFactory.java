package sk.fd.myresourceserver.api;

import org.keycloak.authorization.client.AuthzClient;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.servlet.ServletContext;

@ApplicationScoped
public class KeycloakAuthzClientFactory {

    @Inject
    private ServletContext servletContext;

    private AuthzClient authzClient;

    @PostConstruct
    public void postConstruct() {
/*
        Configuration configuration = new Configuration();
        configuration.setAuthServerUrl("http://keycloak:8080/auth");
        configuration.setRealm("Test");
        configuration.setSslRequired("external");
        configuration.setResource("my-resource-server");
        configuration.setVerifyTokenAudience(false);

        Map<String, Object> credentials = new HashMap<>();
        credentials.put("secret", "4a063a63-e9dd-453c-9618-22e022946d69");
        configuration.setCredentials(credentials);

        configuration.setConfidentialPort(0);

        authzClient = AuthzClient.create(configuration);
*/
        authzClient = AuthzClient.create(servletContext.getResourceAsStream("/WEB-INF/keycloak.json"));
    }

    @Produces
    public AuthzClient getAuthzClient() {
        return authzClient;
    }
}
