package sk.fd.myresourceserver.api;


import io.swagger.v3.oas.annotations.ExternalDocumentation;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.*;
import io.swagger.v3.oas.annotations.servers.Server;
import org.keycloak.KeycloakSecurityContext;
import org.keycloak.authorization.client.AuthzClient;
import org.keycloak.authorization.client.representation.TokenIntrospectionResponse;
import org.keycloak.authorization.client.resource.ProtectedResource;
import org.keycloak.representations.idm.authorization.AuthorizationRequest;
import org.keycloak.representations.idm.authorization.AuthorizationResponse;
import org.keycloak.representations.idm.authorization.Permission;
import org.keycloak.representations.idm.authorization.ResourceRepresentation;
import org.slf4j.Logger;
import sk.fd.myresourceserver.ResourceService;
import sk.fd.myresourceserver.model.MyResourceDTO;
import sk.fd.myresourceserver.model.PingResponse;
import sk.fd.myresourceserver.model.PingStatus;
import sk.fd.myresourceserver.model.ResourceResponse;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@OpenAPIDefinition(
        info = @Info(
                title = "My Resource Server",
                description = "Just a prototype.",
                version = "1.0.0"),
        servers = {
                @Server(url = "/myresourceserver")
        },
        externalDocs = @ExternalDocumentation(description = "RFC 6750 The OAuth 2.0 Authorization Framework: Bearer Token Usage", url = "https://tools.ietf.org/html/rfc6750")
)
@SecuritySchemes({
// swagger UI does not support OPENIDCONNECT security scheme, so this does not really matter
// oauth2 with implicit flow works, but it is not recommended
        @SecurityScheme(
                type = SecuritySchemeType.OPENIDCONNECT,
                name = "openId",
                openIdConnectUrl = "http://keycloak:8080/auth/realms/Test/.well-known/openid-configuration"
        ),
        @SecurityScheme(
                type = SecuritySchemeType.OAUTH2,
                name = "oauth2",
                flows = @OAuthFlows(implicit = @OAuthFlow(
                        authorizationUrl = "http://keycloak:8080/auth/realms/Test/protocol/openid-connect/auth",
                        scopes = {@OAuthScope(name = "urn:my-resource-server:scopes:view")}
                ))
        )
})
@ApplicationScoped
@Path("/resources")
public class MyResourceServerApi {

    @Inject
    private Logger logger;

    @Inject
    private ResourceService resourceService;

    @Inject
    private AuthzClient authzClient;

    @Context
    private HttpServletRequest httpRequest;

    @GET
    @Produces({"application/json"})
    @Operation(
            summary = "Register resources with Keycloak.",
            description = "Register resources with Keycloak.",
            tags = {"register"},
            security = {
                    @SecurityRequirement(name = "openId"),
                    @SecurityRequirement(name = "oauth2")
            }
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(schema = @Schema(implementation = ResourceResponse.class))),
            @ApiResponse(responseCode = "400", description = "The request is missing a parameter, or is otherwise malformed."),
            @ApiResponse(responseCode = "500", description = "Internal Server Error.")
    })
    @Path("/register")
    public Response registerResources() {
        // this only adds and updates resources to Keycloak, however if resource is not valid anymore it is not removed from Keycloak, however this should be doable as well

        ProtectedResource resourceClient = authzClient.protection().resource();

        List<String> resourceIdList = resourceService.findAllResources().stream()
                .map(resourceDTO -> {
                    ResourceRepresentation resourceRepresentation = new ResourceRepresentation();

                    resourceRepresentation.setName(resourceDTO.getName());
                    resourceRepresentation.setDisplayName(resourceDTO.getDisplayName());
                    resourceRepresentation.setType("urn:my-resource-server:resources");
                    resourceRepresentation.setOwnerManagedAccess(true);
                    resourceRepresentation.addScope("urn:my-resource-server:scopes:view");

                    Map<String, List<String>> attributes = new HashMap<>();
                    List<String> externalId = new ArrayList<>();
                    externalId.add(resourceDTO.getId().toString());
                    attributes.put("externalId", externalId);
                    resourceRepresentation.setAttributes(attributes);

                    return resourceRepresentation;
                }).map(resourceRepresentation -> {
                    ResourceRepresentation result;

                    ResourceRepresentation existingResource = resourceClient.findByName(resourceRepresentation.getName());

                    if (existingResource != null) {
                        resourceRepresentation.setId(existingResource.getId());
                        resourceClient.update(resourceRepresentation);
                        result = resourceRepresentation;
                    } else {
                        result = resourceClient.create(resourceRepresentation);
                    }

                    return result.getId();
                }).collect(Collectors.toList());


        return Response.ok().entity(resourceIdList).build();
    }


    @GET
    @Produces({"application/json"})
    @Operation(
            summary = "Gets resources available for logged in user.",
            description = "Gets resources available for logged in user.",
            tags = {"resources"},
            security = {
                    @SecurityRequirement(name = "openId"),
                    @SecurityRequirement(name = "oauth2")
            }
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(schema = @Schema(implementation = ResourceResponse.class))),
            @ApiResponse(responseCode = "400", description = "The request is missing a parameter, or is otherwise malformed."),
            @ApiResponse(responseCode = "500", description = "Internal Server Error.")
    })
    @Path("/some")
    public Response findSomeResources() {
        logger.info("Method findSomeResources resources invoked.");

        KeycloakSecurityContext keycloakSecurityContext = (KeycloakSecurityContext) httpRequest.getAttribute(KeycloakSecurityContext.class.getName());

// toto funguje, za predpokladu, ze sa sem posle uz ten RPT s permissionami z "my-resource-server" clienta
/*
        return Response.ok().entity(new ResourceResponse(
                resourceService.findAllResources().stream()
                        .filter(myResourceDTO -> keycloakSecurityContext.getAuthorizationContext().hasPermission(myResourceDTO.getName(), "urn:my-resource-server:scopes:view"))
                        .collect(Collectors.toList())
        )).build();
*/

        AuthorizationRequest rptRequest = new AuthorizationRequest();
        AuthorizationResponse rptResponse = authzClient.authorization(keycloakSecurityContext.getTokenString()).authorize(rptRequest);
        TokenIntrospectionResponse requestingPartyToken = authzClient.protection().introspectRequestingPartyToken(rptResponse.getToken());

        Response response;

        PermissionGuard permissionGuard = new PermissionGuard(requestingPartyToken.getPermissions());

        if (requestingPartyToken.getActive()) {

            List<MyResourceDTO> grantedResources = resourceService.findAllResources().stream()
                    .filter(myResourceDTO -> permissionGuard.hasPermission(myResourceDTO.getName(), "urn:my-resource-server:scopes:view"))
                    .collect(Collectors.toList());

            response = Response.ok().entity(new ResourceResponse(grantedResources)).build();
        } else {
            response = Response.status(Response.Status.FORBIDDEN).build();
        }

        return response;
    }

    static class PermissionGuard {
        private List<Permission> permissions;

        PermissionGuard(List<Permission> permissions) {
            this.permissions = permissions;
        }

        boolean hasPermission(String resourceName, String scopeName) {
            return permissions.stream().anyMatch(permission ->
                    (permission.getResourceName().equalsIgnoreCase(resourceName) || permission.getResourceId().equalsIgnoreCase(resourceName))
                            && (scopeName == null || permission.getScopes().contains(scopeName)));
        }
    }


    @GET
    @Produces({"application/json"})
    @Operation(
            summary = "Gets ALL resources.",
            description = "Gets ALL resources.",
            tags = {"resources"},
            security = {
                    @SecurityRequirement(name = "openId"),
                    @SecurityRequirement(name = "oauth2")
            }
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(schema = @Schema(implementation = ResourceResponse.class))),
            @ApiResponse(responseCode = "400", description = "The request is missing a parameter, or is otherwise malformed."),
            @ApiResponse(responseCode = "500", description = "Internal Server Error.")
    })
    @Path("/all")
    public Response findAllResources() {
        return Response.ok().entity(new ResourceResponse(
                resourceService.findAllResources()
        )).build();
    }


    @Path("/ping")
    @GET
    @Produces({"application/json"})
    @Operation(summary = "Ping service", description = "General ping method.", tags = {"ping"})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "OK", content = @Content(schema = @Schema(implementation = PingResponse.class)))
    })
    public Response ping() {
        return Response.ok().entity(new PingResponse(PingStatus.OK)).build();
    }


}
