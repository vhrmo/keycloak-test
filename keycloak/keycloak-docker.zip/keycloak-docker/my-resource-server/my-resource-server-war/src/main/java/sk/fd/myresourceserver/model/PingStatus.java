package sk.fd.myresourceserver.model;

public enum PingStatus {
    OK, ERROR
}
