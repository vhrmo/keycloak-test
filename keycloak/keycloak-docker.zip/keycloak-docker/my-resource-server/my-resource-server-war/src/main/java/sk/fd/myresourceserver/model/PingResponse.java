package sk.fd.myresourceserver.model;

import io.swagger.v3.oas.annotations.media.Schema;

public class PingResponse {

    private PingStatus status;

    public PingResponse(PingStatus status) {
        this.status = status;
    }

    @Schema(description = "Overall status.")
    public PingStatus getStatus() {
        return status;
    }

}
