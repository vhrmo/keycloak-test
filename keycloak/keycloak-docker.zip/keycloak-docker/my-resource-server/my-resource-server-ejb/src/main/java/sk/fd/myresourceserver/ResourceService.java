package sk.fd.myresourceserver;


import org.slf4j.Logger;
import sk.fd.myresourceserver.model.MyResourceDTO;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;


@Stateless
@LocalBean
public class ResourceService {

/*
    @Inject
    private Logger logger;
*/

    private List<MyResourceDTO> allResources;

    @PostConstruct
    public void postConstruct() {
        allResources = new ArrayList<>();

        allResources.add(new MyResourceDTO(1, "car", "Car"));
        allResources.add(new MyResourceDTO(2, "bike", "Bike"));
        allResources.add(new MyResourceDTO(3, "tram", "Tram"));
        allResources.add(new MyResourceDTO(4, "train", "Train"));
        allResources.add(new MyResourceDTO(5, "plane", "Plane"));
    }

    public List<MyResourceDTO> findAllResources() {
        return allResources;
    }


}
