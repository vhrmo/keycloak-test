package sk.fd.myresourceserver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.inject.Named;

@ApplicationScoped
public class Utils {

    /**
     * Makes logger initialization copy/paste-able and makes sure only slf4j facade is used.
     *
     * @param injectionPoint metadata where logger is injected
     * @return logger with category already set properly
     */
    @Produces
    public Logger produceLog(InjectionPoint injectionPoint) {
        return LoggerFactory.getLogger(injectionPoint.getMember().getDeclaringClass());
    }
}
