### Keycloak proof of concept

##### Prerequisites

- maven
- docker compose
- make sure `keycloak` is resolved to `127.0.0.1` (use for example [Telerik Fiddler](https://www.telerik.com/fiddler))

```
cd ./keycloak-docker
mvn clean package

cd ./keycloak
docker-compose up
```

##### ApacheDS

- [ApacheDS docker image](https://hub.docker.com/r/openmicroscopy/apacheds)
- creates instance with partition already configured with context entry: `o=gzs,c=DE`
- contains test data from `bootstrap.ldif`
- can be used with [Apache Directory Studio](https://directory.apache.org/studio)
- port: 389
- user name: **uid=admin,ou=system**
- password: **secret**
- DN: o=gzs,c=DE

##### MySql

- [MySql docker image](https://hub.docker.com/_/mysql)
- database is empty at the beginning, when keycloak server is initialized it creates database schema and when realm is imported it creates data
- URL: `jdbc:mysql://localhost:3306/keycloak`
- user name: **keycloak**
- password: **password**
- root password: **root_password**

##### Keycloak

- [Keycloak docker image](https://hub.docker.com/r/jboss/keycloak/)
- configuration is imported from `test_realm.json`
- [Keycloak console](http://keycloak:8080/auth)
- username: **admin**
- password: **admin**    

##### WildFly
- [WildFly docker image](https://hub.docker.com/r/jboss/wildfly)
- included Keycloak WF adapter [jboss-eap-wildfly-adapter](https://www.keycloak.org/docs/latest/securing_apps/index.html#jboss-eap-wildfly-adapter)
- [Keycloak download page](https://www.keycloak.org/downloads.html)
- [WildFly console](http://localhost:9995/console/index.html#home)
- user name: **admin**
- password: **admin**
- wildfly comes with 2 example applications pre-installed [my-resource-server](http://localhost:8085/myresourceserver) and [my-client-app](http://localhost:8085/myclientapp)

### TODO
- rewrite keycloak.json to cli scripts
- make LDAP to resemble production import "gzs" objectClasses
- do not import realm from json, try to create it programmatically see https://github.com/vhrmo/keycloak-test/blob/master/keycloak/tools/run-after-server-start.sh
- investigate all required use cases
- investigate if it is possible to make keycloak work wit gzsDeniedGrp and others


##### CheatSheet

| Command  |
|---|
| `docker-compose build` |
| `docker-compose up` |
| `docker-compose down` |
| `docker network create keycloak-network` |
| `docker network inspect keycloak-network` |
| `docker ps --all` |
| `docker kill keycloak_wildfly` |
| `docker start keycloak_wildfly` |
| `docker exec -it keycloak_wildfly bash` |
| `docker cp keycloak-wildfly-adapter-dist-6.0.1.tar.gz wildfly:/opt/jboss/wildfly/keycloak-wildfly-adapter-dist-6.0.1.tar.gz` |
| `keycloak/bin/standalone.sh -Djboss.socket.binding.port-offset=100 -Dkeycloak.migration.action=export -Dkeycloak.migration.provider=singleFile -Dkeycloak.migration.realmName=Test -Dkeycloak.migration.usersExportStrategy=REALM_FILE -Dkeycloak.migration.file=/tmp/test_realm.json` |

### Functionality observations

##### Portal screen with all applications relevant for logged in user
- there is a [account link](http://localhost:8080/auth/realms/Test/account/applications) with applications listed, but it does not look very nice, maybe custom solution would be better

##### Create user
- when user is created programmatically via admin REST interface, it is created only in Keycloak database, it is not propagated to any user federation provider (LDAP), same goes for user created via admin console UI, option "**Sync Registrations**" in user federation provider must be turned on in order to create users in LDAP as well
- groups are stored in LDAP only once they are assigned to the user

##### Password reset
- password reset works, since password is stored in LDAP
- password reset can be performed via admin REST interface as well

##### Enable/Disable user account
- by default this information is stored in keycloak database in column USER_ENTITY.ENABLED
- BV currently adds user to gzsDeniedGrp in LDAP
- how to make keycloak work with BV together? (force keycloak to read gzsDeniedGrp from LDAP or make BV to store this information in keycloak DB or make BV to use some keycloak rest endpoint)

##### OTP
- works with FreeOTP Android application from RedHat

---


1. https://stackoverflow.com/questions/46184787/gluu-vs-keycloack-vs-wso2-identity-management/54105614#54105614
2. https://gist.github.com/bmaupin/6878fae9abcb63ef43f8ac9b9de8fafd