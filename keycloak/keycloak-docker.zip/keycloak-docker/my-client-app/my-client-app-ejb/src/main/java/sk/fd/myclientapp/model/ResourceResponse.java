package sk.fd.myclientapp.model;

import java.util.List;

public class ResourceResponse {

    private List<MyResourceDTO> resources;

    public ResourceResponse() {
    }

    public ResourceResponse(List<MyResourceDTO> resources) {
        this.resources = resources;
    }

    public List<MyResourceDTO> getResources() {
        return resources;
    }

    public void setResources(List<MyResourceDTO> resources) {
        this.resources = resources;
    }
}
