package sk.fd.myclientapp;

import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
//import org.jboss.ejb3.annotation.SecurityDomain;
import org.keycloak.util.JsonSerialization;
import sk.fd.myclientapp.model.MyResourceDTO;
import sk.fd.myclientapp.model.ResourceResponse;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import java.io.IOException;
import java.io.InputStream;
import java.security.Principal;
import java.util.List;

@Stateless
@LocalBean
//@SecurityDomain("KeycloakDomain")
public class ClientBean {

    @Inject
    private Principal principal;

    @PermitAll
    public String greet() {
        return "Hello " + principal.getName() + ".";
    }

    @PermitAll
    public List<MyResourceDTO> findSomeResources(String accessTokenString) {
        return findResources("http://localhost:8080/myresourceserver/api/resources/some", accessTokenString);
    }

    @RolesAllowed({"gzs_super_admin"})
    public List<MyResourceDTO> findAllResources(String accessTokenString) {
        return findResources("http://localhost:8080/myresourceserver/api/resources/all", accessTokenString);
    }

    private List<MyResourceDTO> findResources(String uri, String accessTokenString) {
        try (CloseableHttpClient client = HttpClients.createDefault()) {

            HttpGet get = new HttpGet(uri);
            get.addHeader("Authorization", "Bearer " + accessTokenString);

            HttpResponse response = client.execute(get);

            StatusLine status = response.getStatusLine();

            if (status.getStatusCode() == 200) {

                try (InputStream is = response.getEntity().getContent()) {
                    return JsonSerialization.readValue(is, ResourceResponse.class).getResources();
                }
            } else {
                throw new RuntimeException("StatusCode: " + status.getStatusCode() + " ReasonPhrase: " + status.getReasonPhrase());
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
