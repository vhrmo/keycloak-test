package sk.fd.myclientapp.model;

public class MyResourceDTO {

    private Integer id;
    private String name;
    private String displayName;

    public MyResourceDTO() {
    }

    public MyResourceDTO(Integer id, String name, String displayName) {
        this.id = id;
        this.name = name;
        this.displayName = displayName;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDisplayName() {
        return displayName;
    }
}
