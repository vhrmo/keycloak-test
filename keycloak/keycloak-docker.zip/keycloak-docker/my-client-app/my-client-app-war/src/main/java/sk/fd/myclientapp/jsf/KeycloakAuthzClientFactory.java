package sk.fd.myclientapp.jsf;

import org.keycloak.authorization.client.AuthzClient;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.servlet.ServletContext;

@ApplicationScoped
public class KeycloakAuthzClientFactory {

    @Inject
    private ServletContext servletContext;

    private AuthzClient authzClient;

    @PostConstruct
    public void postConstruct() {
        authzClient = AuthzClient.create(servletContext.getResourceAsStream("/WEB-INF/keycloak.json"));
    }

    @Produces
    public AuthzClient getAuthzClient() {
        return authzClient;
    }
}
