package sk.fd.myclientapp.jsf;

import org.keycloak.KeycloakSecurityContext;
import org.keycloak.representations.AccessToken;
import org.slf4j.Logger;
import sk.fd.myclientapp.ClientBean;
import sk.fd.myclientapp.model.MyResourceDTO;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.util.List;


@Named
@RequestScoped
public class MainBean {

    @Inject
    private Logger logger;

    @Inject
    private HttpServletRequest httpRequest;

    @Inject
    private ClientBean clientBean;

    private String realm;
    private String userName;
    private String givenName;
    private String familyName;
    private String email;
    private String greeting;
    private String someResources;
    private String allResources;


    @PostConstruct
    void postConstruct() {
        KeycloakSecurityContext keycloakSecurityContext = (KeycloakSecurityContext) httpRequest.getAttribute(KeycloakSecurityContext.class.getName());
        realm = keycloakSecurityContext.getRealm();

        AccessToken accessToken = keycloakSecurityContext.getToken();
        userName = accessToken.getPreferredUsername();
        givenName = accessToken.getGivenName();
        familyName = accessToken.getFamilyName();
        email = accessToken.getEmail();

        greeting = clientBean.greet();


// toto funguje, ale nepripada mi to spravne, ten RPT token ziskavat uz tu...
/*
        Configuration configuration = new Configuration();
        configuration.setAuthServerUrl("http://keycloak:8080/auth");
        configuration.setRealm("Test");
        configuration.setSslRequired("external");
        configuration.setResource("my-resource-server");
        configuration.setVerifyTokenAudience(false);
        Map<String, Object> credentials = new HashMap<>();
        credentials.put("secret", "4a063a63-e9dd-453c-9618-22e022946d69");
        configuration.setCredentials(credentials);
        configuration.setConfidentialPort(0);

        AuthzClient authzClient = AuthzClient.create(configuration);

        AuthorizationRequest request = new AuthorizationRequest();
        request.setSubjectToken(keycloakSecurityContext.getTokenString());
        AuthorizationResponse response = authzClient.authorization().authorize(request);

        resources = clientBean.findSomeResources(response.getToken()).stream()
                .map(MyResourceDTO::getName)
                .reduce((s1, s2) -> s1 + " " + s2).orElse("");
*/

        someResources = convertToString(clientBean.findSomeResources(keycloakSecurityContext.getTokenString()));

        allResources = httpRequest.isUserInRole("gzs_super_admin") ? convertToString(clientBean.findAllResources(keycloakSecurityContext.getTokenString())) : "";

    }

    private String convertToString(List<MyResourceDTO> myResourceDTOs) {
        return myResourceDTOs.stream()
                .map(MyResourceDTO::getName)
                .reduce((s1, s2) -> s1 + " " + s2).orElse("");
    }

    public String logout() throws ServletException {
        httpRequest.logout();
        return "index";
    }

    public String getRealm() {
        return realm;
    }

    public String getUserName() {
        return userName;
    }

    public String getGivenName() {
        return givenName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public String getEmail() {
        return email;
    }

    public String getGreeting() {
        return greeting;
    }

    public String getSomeResources() {
        return someResources;
    }

    public String getAllResources() {
        return allResources;
    }

}
