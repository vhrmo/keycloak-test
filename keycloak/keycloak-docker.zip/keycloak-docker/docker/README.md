### Docker compose

```
cd ./src/test/resources/keycloak
docker-compose up
```

### Starting containers manually

##### ApacheDS

- [ApacheDS docker image](https://hub.docker.com/r/openmicroscopy/apacheds)
- creates instance with partition already configured with context entry: `o=gzs,c=DE`
- `docker run --name ldap --net keycloak-network -d -p 389:10389 -e APACHEDS_INSTANCE=default -v ./docker/src/test/resources/config.ldif:/bootstrap/conf/config.ldif:ro openmicroscopy/apacheds`
- user name: uid=admin,ou=system
- password: secret
- DN: o=gzs,c=DE

##### MySql
- [MySql docker image](https://hub.docker.com/_/mysql)
- MySql 8 is not compatible with Keycloak, therefore version 5.x is used here
- `docker run --name mysql -d --net keycloak-network -p 3306:3306 -e MYSQL_DATABASE=keycloak -e MYSQL_USER=keycloak -e MYSQL_PASSWORD=password -e MYSQL_ROOT_PASSWORD=root_password mysql:5.7.27`

##### Keycloak

- [Keycloak docker image](https://hub.docker.com/r/jboss/keycloak/)
- `docker run --name keycloak --net keycloak-network -d -p 8080:8080 -e KEYCLOAK_USER=admin -e KEYCLOAK_PASSWORD=admin jboss/keycloak`
- [Keycloak console](http://localhost:8080/auth)
- [Test realm console](http://localhost:8080/auth/admin/Test/console/index.html)    
- realm backup example: `keycloak/bin/standalone.sh -Djboss.socket.binding.port-offset=100 -Dkeycloak.migration.action=export -Dkeycloak.migration.provider=singleFile -Dkeycloak.migration.realmName=Test -Dkeycloak.migration.usersExportStrategy=REALM_FILE -Dkeycloak.migration.file=/tmp/test_realm.json`
- preview features: `profile.properties` **admin_fine_grained_authz**
- [Keycloak console](http://localhost:8080/auth)
- [Test realm console](http://localhost:8080/auth/admin/Test/console/index.html)    

##### WildFly
- [WildFly docker image](https://hub.docker.com/r/jboss/wildfly)
- `docker run --name wildfly -d --net keycloak-network -p 8085:8080 -p 9995:9990 jboss/wildfly /opt/jboss/wildfly/bin/standalone.sh -bmanagement 0.0.0.0`
- `docker run --name wildfly -d --net keycloak-network -p 8085:8080 -p 9995:9990 -p 8787:8787 my/wildfly:1.0 /opt/jboss/wildfly/bin/standalone.sh -bmanagement 0.0.0.0 --debug`
- installed Keycloak WF adapter like so: [jboss-eap-wildfly-adapter](https://www.keycloak.org/docs/latest/securing_apps/index.html#jboss-eap-wildfly-adapter)
- [Keycloak download page](https://www.keycloak.org/downloads.html)
- [WildFly console](http://localhost:9995/console/index.html#home)
- user name: admin
- password: admin

##### Docker CheatSheet

| Command  |
|---|
| `docker network create keycloak-network` |
| `docker network inspect keycloak-network` |
| `docker ps --all` |
| `docker kill keycloak` |
| `docker start keycloak` |
| `docker exec -it keycloak bash` |
| `docker cp keycloak-wildfly-adapter-dist-6.0.1.tar.gz wildfly:/opt/jboss/wildfly/keycloak-wildfly-adapter-dist-6.0.1.tar.gz` |
